<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
    <path d="M7 3h8l5 5v13a1 1 0 0 1 -1 1h-12a1 1 0 0 1 -1 -1v-17a1 1 0 0 1 1 -1" />
    <path d="M14 3v5h5" />
    <path d="M9 13h6" />
    <path d="M9 17h6" />
</svg>
