<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
    <path d="M3 21h18" />
    <path d="M5 21v-14a1 1 0 0 1 1 -1h12a1 1 0 0 1 1 1v14" />
    <path d="M9 10h1" />
    <path d="M9 14h1" />
    <path d="M14 10h1" />
    <path d="M14 14h1" />
</svg>
