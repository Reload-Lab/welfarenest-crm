<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
    <path d="M12 3l2.5 5l5.5 .8l-4 3.9l.9 5.3l-4.9 -2.6l-4.9 2.6l.9 -5.3l-4 -3.9l5.5 -.8z" />
</svg>
