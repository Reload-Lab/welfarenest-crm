<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
    <path d="M8 7a3 3 0 1 0 0 .01" />
    <path d="M16 17a3 3 0 1 0 0 .01" />
    <path d="M10.5 9.5l3 5" />
</svg>
