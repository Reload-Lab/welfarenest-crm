<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
    <path d="M12 21l-7 -7a5 5 0 0 1 7 -7l0 0a5 5 0 0 1 7 7z" />
    <path d="M9 12l2 2l4 -4" />
</svg>
