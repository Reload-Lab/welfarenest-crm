<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
    <path d="M12 5c4.5 0 8.4 2.5 10 7c-1.6 4.5 -5.5 7 -10 7s-8.4 -2.5 -10 -7c1.6 -4.5 5.5 -7 10 -7z" />
    <path d="M12 9a3 3 0 1 0 0 6a3 3 0 0 0 0 -6z" />
</svg>
