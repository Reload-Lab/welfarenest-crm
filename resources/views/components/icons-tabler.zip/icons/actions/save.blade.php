<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
    <path d="M6 3h10l5 5v13a1 1 0 0 1 -1 1h-16a1 1 0 0 1 -1 -1v-17a1 1 0 0 1 1 -1h2" />
    <path d="M17 21v-8h-10v8" />
    <path d="M7 3v5h8" />
</svg>
