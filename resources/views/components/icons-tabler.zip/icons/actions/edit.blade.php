<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
    <path d="M7 20h10" />
    <path d="M6 16l10.5 -10.5a2.121 2.121 0 1 1 3 3l-10.5 10.5l-4 1z" />
</svg>
