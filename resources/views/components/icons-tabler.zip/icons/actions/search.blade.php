<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
    <path d="M10 4a6 6 0 1 0 0 12a6 6 0 0 0 0 -12z" />
    <path d="M14.5 14.5l5.5 5.5" />
</svg>
